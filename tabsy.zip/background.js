(/* @__PURE__ */ ((e, t) => () => (t || (e((t = { exports: {} }).exports, t), e = null), t.exports))(((e, t) => {
	(function(n, r) {
		if (typeof define == "function" && define.amd) define("webextension-polyfill", ["module"], r);
		else if (e !== void 0) r(t);
		else {
			var i = { exports: {} };
			r(i), n.browser = i.exports;
		}
	})(typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : e, function(e) {
		if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) throw Error("This script should only be loaded in a browser extension.");
		globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id ? e.exports = globalThis.browser : e.exports = ((e) => {
			let t = {
				alarms: {
					clear: {
						minArgs: 0,
						maxArgs: 1
					},
					clearAll: {
						minArgs: 0,
						maxArgs: 0
					},
					get: {
						minArgs: 0,
						maxArgs: 1
					},
					getAll: {
						minArgs: 0,
						maxArgs: 0
					}
				},
				bookmarks: {
					create: {
						minArgs: 1,
						maxArgs: 1
					},
					get: {
						minArgs: 1,
						maxArgs: 1
					},
					getChildren: {
						minArgs: 1,
						maxArgs: 1
					},
					getRecent: {
						minArgs: 1,
						maxArgs: 1
					},
					getSubTree: {
						minArgs: 1,
						maxArgs: 1
					},
					getTree: {
						minArgs: 0,
						maxArgs: 0
					},
					move: {
						minArgs: 2,
						maxArgs: 2
					},
					remove: {
						minArgs: 1,
						maxArgs: 1
					},
					removeTree: {
						minArgs: 1,
						maxArgs: 1
					},
					search: {
						minArgs: 1,
						maxArgs: 1
					},
					update: {
						minArgs: 2,
						maxArgs: 2
					}
				},
				browserAction: {
					disable: {
						minArgs: 0,
						maxArgs: 1,
						fallbackToNoCallback: !0
					},
					enable: {
						minArgs: 0,
						maxArgs: 1,
						fallbackToNoCallback: !0
					},
					getBadgeBackgroundColor: {
						minArgs: 1,
						maxArgs: 1
					},
					getBadgeText: {
						minArgs: 1,
						maxArgs: 1
					},
					getPopup: {
						minArgs: 1,
						maxArgs: 1
					},
					getTitle: {
						minArgs: 1,
						maxArgs: 1
					},
					openPopup: {
						minArgs: 0,
						maxArgs: 0
					},
					setBadgeBackgroundColor: {
						minArgs: 1,
						maxArgs: 1,
						fallbackToNoCallback: !0
					},
					setBadgeText: {
						minArgs: 1,
						maxArgs: 1,
						fallbackToNoCallback: !0
					},
					setIcon: {
						minArgs: 1,
						maxArgs: 1
					},
					setPopup: {
						minArgs: 1,
						maxArgs: 1,
						fallbackToNoCallback: !0
					},
					setTitle: {
						minArgs: 1,
						maxArgs: 1,
						fallbackToNoCallback: !0
					}
				},
				browsingData: {
					remove: {
						minArgs: 2,
						maxArgs: 2
					},
					removeCache: {
						minArgs: 1,
						maxArgs: 1
					},
					removeCookies: {
						minArgs: 1,
						maxArgs: 1
					},
					removeDownloads: {
						minArgs: 1,
						maxArgs: 1
					},
					removeFormData: {
						minArgs: 1,
						maxArgs: 1
					},
					removeHistory: {
						minArgs: 1,
						maxArgs: 1
					},
					removeLocalStorage: {
						minArgs: 1,
						maxArgs: 1
					},
					removePasswords: {
						minArgs: 1,
						maxArgs: 1
					},
					removePluginData: {
						minArgs: 1,
						maxArgs: 1
					},
					settings: {
						minArgs: 0,
						maxArgs: 0
					}
				},
				commands: { getAll: {
					minArgs: 0,
					maxArgs: 0
				} },
				contextMenus: {
					remove: {
						minArgs: 1,
						maxArgs: 1
					},
					removeAll: {
						minArgs: 0,
						maxArgs: 0
					},
					update: {
						minArgs: 2,
						maxArgs: 2
					}
				},
				cookies: {
					get: {
						minArgs: 1,
						maxArgs: 1
					},
					getAll: {
						minArgs: 1,
						maxArgs: 1
					},
					getAllCookieStores: {
						minArgs: 0,
						maxArgs: 0
					},
					remove: {
						minArgs: 1,
						maxArgs: 1
					},
					set: {
						minArgs: 1,
						maxArgs: 1
					}
				},
				devtools: {
					inspectedWindow: { eval: {
						minArgs: 1,
						maxArgs: 2,
						singleCallbackArg: !1
					} },
					panels: {
						create: {
							minArgs: 3,
							maxArgs: 3,
							singleCallbackArg: !0
						},
						elements: { createSidebarPane: {
							minArgs: 1,
							maxArgs: 1
						} }
					}
				},
				downloads: {
					cancel: {
						minArgs: 1,
						maxArgs: 1
					},
					download: {
						minArgs: 1,
						maxArgs: 1
					},
					erase: {
						minArgs: 1,
						maxArgs: 1
					},
					getFileIcon: {
						minArgs: 1,
						maxArgs: 2
					},
					open: {
						minArgs: 1,
						maxArgs: 1,
						fallbackToNoCallback: !0
					},
					pause: {
						minArgs: 1,
						maxArgs: 1
					},
					removeFile: {
						minArgs: 1,
						maxArgs: 1
					},
					resume: {
						minArgs: 1,
						maxArgs: 1
					},
					search: {
						minArgs: 1,
						maxArgs: 1
					},
					show: {
						minArgs: 1,
						maxArgs: 1,
						fallbackToNoCallback: !0
					}
				},
				extension: {
					isAllowedFileSchemeAccess: {
						minArgs: 0,
						maxArgs: 0
					},
					isAllowedIncognitoAccess: {
						minArgs: 0,
						maxArgs: 0
					}
				},
				history: {
					addUrl: {
						minArgs: 1,
						maxArgs: 1
					},
					deleteAll: {
						minArgs: 0,
						maxArgs: 0
					},
					deleteRange: {
						minArgs: 1,
						maxArgs: 1
					},
					deleteUrl: {
						minArgs: 1,
						maxArgs: 1
					},
					getVisits: {
						minArgs: 1,
						maxArgs: 1
					},
					search: {
						minArgs: 1,
						maxArgs: 1
					}
				},
				i18n: {
					detectLanguage: {
						minArgs: 1,
						maxArgs: 1
					},
					getAcceptLanguages: {
						minArgs: 0,
						maxArgs: 0
					}
				},
				identity: { launchWebAuthFlow: {
					minArgs: 1,
					maxArgs: 1
				} },
				idle: { queryState: {
					minArgs: 1,
					maxArgs: 1
				} },
				management: {
					get: {
						minArgs: 1,
						maxArgs: 1
					},
					getAll: {
						minArgs: 0,
						maxArgs: 0
					},
					getSelf: {
						minArgs: 0,
						maxArgs: 0
					},
					setEnabled: {
						minArgs: 2,
						maxArgs: 2
					},
					uninstallSelf: {
						minArgs: 0,
						maxArgs: 1
					}
				},
				notifications: {
					clear: {
						minArgs: 1,
						maxArgs: 1
					},
					create: {
						minArgs: 1,
						maxArgs: 2
					},
					getAll: {
						minArgs: 0,
						maxArgs: 0
					},
					getPermissionLevel: {
						minArgs: 0,
						maxArgs: 0
					},
					update: {
						minArgs: 2,
						maxArgs: 2
					}
				},
				pageAction: {
					getPopup: {
						minArgs: 1,
						maxArgs: 1
					},
					getTitle: {
						minArgs: 1,
						maxArgs: 1
					},
					hide: {
						minArgs: 1,
						maxArgs: 1,
						fallbackToNoCallback: !0
					},
					setIcon: {
						minArgs: 1,
						maxArgs: 1
					},
					setPopup: {
						minArgs: 1,
						maxArgs: 1,
						fallbackToNoCallback: !0
					},
					setTitle: {
						minArgs: 1,
						maxArgs: 1,
						fallbackToNoCallback: !0
					},
					show: {
						minArgs: 1,
						maxArgs: 1,
						fallbackToNoCallback: !0
					}
				},
				permissions: {
					contains: {
						minArgs: 1,
						maxArgs: 1
					},
					getAll: {
						minArgs: 0,
						maxArgs: 0
					},
					remove: {
						minArgs: 1,
						maxArgs: 1
					},
					request: {
						minArgs: 1,
						maxArgs: 1
					}
				},
				runtime: {
					getBackgroundPage: {
						minArgs: 0,
						maxArgs: 0
					},
					getPlatformInfo: {
						minArgs: 0,
						maxArgs: 0
					},
					openOptionsPage: {
						minArgs: 0,
						maxArgs: 0
					},
					requestUpdateCheck: {
						minArgs: 0,
						maxArgs: 0
					},
					sendMessage: {
						minArgs: 1,
						maxArgs: 3
					},
					sendNativeMessage: {
						minArgs: 2,
						maxArgs: 2
					},
					setUninstallURL: {
						minArgs: 1,
						maxArgs: 1
					}
				},
				sessions: {
					getDevices: {
						minArgs: 0,
						maxArgs: 1
					},
					getRecentlyClosed: {
						minArgs: 0,
						maxArgs: 1
					},
					restore: {
						minArgs: 0,
						maxArgs: 1
					}
				},
				storage: {
					local: {
						clear: {
							minArgs: 0,
							maxArgs: 0
						},
						get: {
							minArgs: 0,
							maxArgs: 1
						},
						getBytesInUse: {
							minArgs: 0,
							maxArgs: 1
						},
						remove: {
							minArgs: 1,
							maxArgs: 1
						},
						set: {
							minArgs: 1,
							maxArgs: 1
						}
					},
					managed: {
						get: {
							minArgs: 0,
							maxArgs: 1
						},
						getBytesInUse: {
							minArgs: 0,
							maxArgs: 1
						}
					},
					sync: {
						clear: {
							minArgs: 0,
							maxArgs: 0
						},
						get: {
							minArgs: 0,
							maxArgs: 1
						},
						getBytesInUse: {
							minArgs: 0,
							maxArgs: 1
						},
						remove: {
							minArgs: 1,
							maxArgs: 1
						},
						set: {
							minArgs: 1,
							maxArgs: 1
						}
					}
				},
				tabs: {
					captureVisibleTab: {
						minArgs: 0,
						maxArgs: 2
					},
					create: {
						minArgs: 1,
						maxArgs: 1
					},
					detectLanguage: {
						minArgs: 0,
						maxArgs: 1
					},
					discard: {
						minArgs: 0,
						maxArgs: 1
					},
					duplicate: {
						minArgs: 1,
						maxArgs: 1
					},
					executeScript: {
						minArgs: 1,
						maxArgs: 2
					},
					get: {
						minArgs: 1,
						maxArgs: 1
					},
					getCurrent: {
						minArgs: 0,
						maxArgs: 0
					},
					getZoom: {
						minArgs: 0,
						maxArgs: 1
					},
					getZoomSettings: {
						minArgs: 0,
						maxArgs: 1
					},
					goBack: {
						minArgs: 0,
						maxArgs: 1
					},
					goForward: {
						minArgs: 0,
						maxArgs: 1
					},
					highlight: {
						minArgs: 1,
						maxArgs: 1
					},
					insertCSS: {
						minArgs: 1,
						maxArgs: 2
					},
					move: {
						minArgs: 2,
						maxArgs: 2
					},
					query: {
						minArgs: 1,
						maxArgs: 1
					},
					reload: {
						minArgs: 0,
						maxArgs: 2
					},
					remove: {
						minArgs: 1,
						maxArgs: 1
					},
					removeCSS: {
						minArgs: 1,
						maxArgs: 2
					},
					sendMessage: {
						minArgs: 2,
						maxArgs: 3
					},
					setZoom: {
						minArgs: 1,
						maxArgs: 2
					},
					setZoomSettings: {
						minArgs: 1,
						maxArgs: 2
					},
					update: {
						minArgs: 1,
						maxArgs: 2
					}
				},
				topSites: { get: {
					minArgs: 0,
					maxArgs: 0
				} },
				webNavigation: {
					getAllFrames: {
						minArgs: 1,
						maxArgs: 1
					},
					getFrame: {
						minArgs: 1,
						maxArgs: 1
					}
				},
				webRequest: { handlerBehaviorChanged: {
					minArgs: 0,
					maxArgs: 0
				} },
				windows: {
					create: {
						minArgs: 0,
						maxArgs: 1
					},
					get: {
						minArgs: 1,
						maxArgs: 2
					},
					getAll: {
						minArgs: 0,
						maxArgs: 1
					},
					getCurrent: {
						minArgs: 0,
						maxArgs: 1
					},
					getLastFocused: {
						minArgs: 0,
						maxArgs: 1
					},
					remove: {
						minArgs: 1,
						maxArgs: 1
					},
					update: {
						minArgs: 2,
						maxArgs: 2
					}
				}
			};
			if (Object.keys(t).length === 0) throw Error("api-metadata.json has not been included in browser-polyfill");
			class n extends WeakMap {
				constructor(e, t = void 0) {
					super(t), this.createItem = e;
				}
				get(e) {
					return this.has(e) || this.set(e, this.createItem(e)), super.get(e);
				}
			}
			let r = (e) => e && typeof e == "object" && typeof e.then == "function", i = (t, n) => (...r) => {
				e.runtime.lastError ? t.reject(Error(e.runtime.lastError.message)) : n.singleCallbackArg || r.length <= 1 && n.singleCallbackArg !== !1 ? t.resolve(r[0]) : t.resolve(r);
			}, a = (e) => e == 1 ? "argument" : "arguments", o = (e, t) => function(n, ...r) {
				if (r.length < t.minArgs) throw Error(`Expected at least ${t.minArgs} ${a(t.minArgs)} for ${e}(), got ${r.length}`);
				if (r.length > t.maxArgs) throw Error(`Expected at most ${t.maxArgs} ${a(t.maxArgs)} for ${e}(), got ${r.length}`);
				return new Promise((a, o) => {
					if (t.fallbackToNoCallback) try {
						n[e](...r, i({
							resolve: a,
							reject: o
						}, t));
					} catch (i) {
						console.warn(`${e} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, i), n[e](...r), t.fallbackToNoCallback = !1, t.noCallback = !0, a();
					}
					else t.noCallback ? (n[e](...r), a()) : n[e](...r, i({
						resolve: a,
						reject: o
					}, t));
				});
			}, s = (e, t, n) => new Proxy(t, { apply(t, r, i) {
				return n.call(r, e, ...i);
			} }), c = Function.call.bind(Object.prototype.hasOwnProperty), l = (e, t = {}, n = {}) => {
				let r = Object.create(null);
				return new Proxy(Object.create(e), {
					has(t, n) {
						return n in e || n in r;
					},
					get(i, a, u) {
						if (a in r) return r[a];
						if (!(a in e)) return;
						let d = e[a];
						if (typeof d == "function") if (typeof t[a] == "function") d = s(e, e[a], t[a]);
						else if (c(n, a)) {
							let t = o(a, n[a]);
							d = s(e, e[a], t);
						} else d = d.bind(e);
						else if (typeof d == "object" && d && (c(t, a) || c(n, a))) d = l(d, t[a], n[a]);
						else if (c(n, "*")) d = l(d, t[a], n["*"]);
						else return Object.defineProperty(r, a, {
							configurable: !0,
							enumerable: !0,
							get() {
								return e[a];
							},
							set(t) {
								e[a] = t;
							}
						}), d;
						return r[a] = d, d;
					},
					set(t, n, i, a) {
						return n in r ? r[n] = i : e[n] = i, !0;
					},
					defineProperty(e, t, n) {
						return Reflect.defineProperty(r, t, n);
					},
					deleteProperty(e, t) {
						return Reflect.deleteProperty(r, t);
					}
				});
			}, u = (e) => ({
				addListener(t, n, ...r) {
					t.addListener(e.get(n), ...r);
				},
				hasListener(t, n) {
					return t.hasListener(e.get(n));
				},
				removeListener(t, n) {
					t.removeListener(e.get(n));
				}
			}), d = new n((e) => typeof e == "function" ? function(t) {
				e(l(t, {}, { getContent: {
					minArgs: 0,
					maxArgs: 0
				} }));
			} : e), f = new n((e) => typeof e == "function" ? function(t, n, i) {
				let a = !1, o, s = new Promise((e) => {
					o = function(t) {
						a = !0, e(t);
					};
				}), c;
				try {
					c = e(t, n, o);
				} catch (e) {
					c = Promise.reject(e);
				}
				let l = c !== !0 && r(c);
				return c !== !0 && !l && !a ? !1 : (((e) => {
					e.then((e) => {
						i(e);
					}, (e) => {
						let t;
						t = e && (e instanceof Error || typeof e.message == "string") ? e.message : "An unexpected error occurred", i({
							__mozWebExtensionPolyfillReject__: !0,
							message: t
						});
					}).catch((e) => {
						console.error("Failed to send onMessage rejected reply", e);
					});
				})(l ? c : s), !0);
			} : e), p = ({ reject: t, resolve: n }, r) => {
				e.runtime.lastError ? e.runtime.lastError.message === "The message port closed before a response was received." ? n() : t(Error(e.runtime.lastError.message)) : r && r.__mozWebExtensionPolyfillReject__ ? t(Error(r.message)) : n(r);
			}, m = (e, t, n, ...r) => {
				if (r.length < t.minArgs) throw Error(`Expected at least ${t.minArgs} ${a(t.minArgs)} for ${e}(), got ${r.length}`);
				if (r.length > t.maxArgs) throw Error(`Expected at most ${t.maxArgs} ${a(t.maxArgs)} for ${e}(), got ${r.length}`);
				return new Promise((e, t) => {
					let i = p.bind(null, {
						resolve: e,
						reject: t
					});
					r.push(i), n.sendMessage(...r);
				});
			}, h = {
				devtools: { network: { onRequestFinished: u(d) } },
				runtime: {
					onMessage: u(f),
					onMessageExternal: u(f),
					sendMessage: m.bind(null, "sendMessage", {
						minArgs: 1,
						maxArgs: 3
					})
				},
				tabs: { sendMessage: m.bind(null, "sendMessage", {
					minArgs: 2,
					maxArgs: 3
				}) }
			}, g = {
				clear: {
					minArgs: 1,
					maxArgs: 1
				},
				get: {
					minArgs: 1,
					maxArgs: 1
				},
				set: {
					minArgs: 1,
					maxArgs: 1
				}
			};
			return t.privacy = {
				network: { "*": g },
				services: { "*": g },
				websites: { "*": g }
			}, l(e, h, t);
		})(chrome);
	});
})))();
var e = 12e3, t = (e) => {
	if (!e || typeof e != "object") return !1;
	let t = e;
	return t.action === "CHECK_BOOKMARK_LINKS_IN_BACKGROUND_TABS" && Array.isArray(t.urls);
}, n = (e) => {
	try {
		let t = new URL(e);
		return t.protocol === "http:" || t.protocol === "https:";
	} catch {
		return !1;
	}
}, r = async (e) => {
	try {
		await chrome.tabs.remove(e);
	} catch {}
}, i = async (t, i = e) => {
	if (!n(t)) return {
		url: t,
		status: "invalid"
	};
	let a;
	try {
		return a = (await chrome.tabs.create({
			url: t,
			active: !1
		})).id, a ? await new Promise((e) => {
			let n = !1, o = (t) => {
				n || (n = !0, clearTimeout(u), chrome.webRequest.onCompleted.removeListener(s), chrome.webRequest.onErrorOccurred.removeListener(c), chrome.tabs.onRemoved.removeListener(l), r(a).finally(() => e(t)));
			}, s = (e) => {
				e.tabId !== a || e.type !== "main_frame" || o({
					url: t,
					status: e.statusCode === 200 ? "ok" : "broken",
					httpStatus: e.statusCode
				});
			}, c = (e) => {
				e.tabId !== a || e.type !== "main_frame" || o({
					url: t,
					status: "broken",
					error: e.error
				});
			}, l = (e) => {
				e === a && o({
					url: t,
					status: "broken",
					error: "Фоновая вкладка была закрыта до завершения проверки"
				});
			}, u = setTimeout(() => {
				o({
					url: t,
					status: "timeout"
				});
			}, i);
			chrome.webRequest.onCompleted.addListener(s, {
				urls: ["<all_urls>"],
				tabId: a,
				types: ["main_frame"]
			}), chrome.webRequest.onErrorOccurred.addListener(c, {
				urls: ["<all_urls>"],
				tabId: a,
				types: ["main_frame"]
			}), chrome.tabs.onRemoved.addListener(l);
		}) : {
			url: t,
			status: "broken",
			error: "Не удалось открыть фоновую вкладку"
		};
	} catch (e) {
		return a && await r(a), {
			url: t,
			status: "broken",
			error: e instanceof Error ? e.message : String(e)
		};
	}
}, a = async (t, n = e) => {
	let r = [];
	for (let e of t) r.push(await i(e, n));
	return r;
};
chrome.runtime.onInstalled.addListener(async (e) => {
	console.log("Extension installed:", e);
}), chrome.runtime.onMessage.addListener((e, n, r) => t(e) ? (a(e.urls, e.timeoutMs).then((e) => r({
	success: !0,
	results: e
})).catch((e) => {
	r({
		success: !1,
		error: e instanceof Error ? e.message : String(e)
	});
}), !0) : !1);
//#endregion
